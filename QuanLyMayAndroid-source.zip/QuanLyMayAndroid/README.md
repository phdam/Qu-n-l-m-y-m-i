# Quản lý máy - Android

Ứng dụng Android mẫu quản lý 18 máy trong 4 nhóm, có tìm kiếm, ghi chú máy, nhật ký bảo trì và đính kèm ảnh/video bằng trình chọn tệp của Android. Dữ liệu ghi chú và nhật ký được lưu cục bộ trên điện thoại hiện tại.

## Biên dịch
Yêu cầu JDK 17 và Gradle 8.9:

```bash
gradle assembleDebug
```

APK đầu ra: `app/build/outputs/apk/debug/app-debug.apk`.

## Lưu ý
Đây là bản khởi đầu mới, chưa đồng bộ dữ liệu giữa nhiều điện thoại, chưa có sao lưu/khôi phục hoặc in A4. Tệp đính kèm lưu dưới dạng URI tham chiếu đến tệp đã chọn; nếu tệp bị xóa/di chuyển hoặc quyền truy cập bị thu hồi, có thể không mở lại được. Giao diện này là bản mới đơn giản, chưa thể bảo đảm giống chính xác giao diện ảnh cũ nếu không có ảnh tham chiếu trong phiên hiện tại.
