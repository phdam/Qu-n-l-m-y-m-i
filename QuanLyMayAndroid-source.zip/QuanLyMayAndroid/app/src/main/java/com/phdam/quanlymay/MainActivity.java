package com.phdam.quanlymay;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private final String[] groups = {"Nhóm máy 1", "Nhóm máy 2", "Nhóm máy 3", "Nhóm máy 4"};
    private final int[] counts = {5, 5, 4, 4};
    private int selectedGroup = 0;
    private LinearLayout root, groupRow, list;
    private EditText searchBox;
    private SharedPreferences prefs;
    private int pendingMachine = 1;
    private static final int PICK_MEDIA = 71;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("quan_ly_may", MODE_PRIVATE);
        buildScreen();
    }

    private int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }
    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setGravity(Gravity.CENTER_VERTICAL); return t;
    }
    private Button button(String label) {
        Button b = new Button(this); b.setText(label); b.setAllCaps(false); b.setTextSize(13); return b;
    }
    private void buildScreen() {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.rgb(245,247,250));
        TextView header = text("QUẢN LÝ MÁY", 22, Color.WHITE, true); header.setPadding(dp(18), dp(18), dp(18), dp(18)); header.setBackgroundColor(Color.rgb(18,78,120));
        root.addView(header, new LinearLayout.LayoutParams(-1, -2));
        TextView sub = text("18 máy • Hồ sơ bảo trì • Ảnh và video", 13, Color.WHITE, false); sub.setPadding(dp(18),0,dp(18),dp(14)); sub.setBackgroundColor(Color.rgb(18,78,120)); root.addView(sub);
        searchBox = new EditText(this); searchBox.setSingleLine(true); searchBox.setHint("Tìm tên máy, mã máy..."); searchBox.setTextSize(15); searchBox.setPadding(dp(12),0,dp(12),0);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, dp(48)); sp.setMargins(dp(12),dp(12),dp(12),dp(8)); root.addView(searchBox, sp);
        groupRow = new LinearLayout(this); groupRow.setPadding(dp(8),0,dp(8),dp(4)); root.addView(groupRow);
        ScrollView scroll = new ScrollView(this); list = new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); list.setPadding(dp(12),dp(4),dp(12),dp(18)); scroll.addView(list); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
        for (int i=0;i<groups.length;i++) { final int g=i; Button b=button(groups[i]); b.setOnClickListener(v->{selectedGroup=g; renderGroups(); renderMachines();}); groupRow.addView(b,new LinearLayout.LayoutParams(0,dp(48),1)); }
        searchBox.addTextChangedListener(new android.text.TextWatcher(){ public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void onTextChanged(CharSequence s,int st,int before,int count){renderMachines();} public void afterTextChanged(android.text.Editable e){} });
        renderGroups(); renderMachines();
    }
    private String machineName(int g,int n) { return "Máy " + (g*5+n); }
    private void renderGroups() {
        for(int i=0;i<groupRow.getChildCount();i++) { Button b=(Button)groupRow.getChildAt(i); b.setText((i==selectedGroup?"✓ ":"")+groups[i]); b.setTextColor(i==selectedGroup?Color.WHITE:Color.rgb(30,70,95)); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(i==selectedGroup?Color.rgb(23,105,170):Color.rgb(224,233,240))); }
    }
    private void renderMachines() {
        if(list==null)return; list.removeAllViews(); String q=searchBox.getText().toString().trim().toLowerCase(Locale.ROOT); int shown=0;
        for(int n=1;n<=counts[selectedGroup];n++) {
            int id=selectedGroup*5+n; if(selectedGroup==3) id=16+n-1;
            String name="Máy "+id; String code="may_"+id;
            String note=prefs.getString(code+"_note", ""); String media=prefs.getString(code+"_media", ""); String logs=prefs.getString(code+"_logs", "");
            if(!q.isEmpty() && !(name.toLowerCase(Locale.ROOT).contains(q) || note.toLowerCase(Locale.ROOT).contains(q) || logs.toLowerCase(Locale.ROOT).contains(q))) continue;
            LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(dp(14),dp(12),dp(14),dp(12)); card.setBackgroundTintList(null); card.setBackground(getDrawable(android.R.drawable.dialog_holo_light_frame));
            LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2); cp.setMargins(0,dp(5),0,dp(7)); list.addView(card,cp);
            TextView title=text(name,18,Color.rgb(24,54,75),true); card.addView(title);
            card.addView(text(groups[selectedGroup],12,Color.rgb(95,110,122),false));
            card.addView(text(note.isEmpty()?"Ghi chú: Chưa nhập":("Ghi chú: "+note),14,Color.DKGRAY,false));
            card.addView(text("Hồ sơ bảo trì: "+(logs.isEmpty()?"Chưa có":logs.split("\\n").length+" mục"),13,Color.rgb(70,95,110),false));
            if(!media.isEmpty()) card.addView(text("Đã đính kèm "+media.split("\\n").length+" ảnh/video",13,Color.rgb(23,105,80),false));
            LinearLayout actions=new LinearLayout(this); actions.setGravity(Gravity.CENTER_VERTICAL); card.addView(actions);
            Button noteBtn=button("Ghi chú / sửa"); noteBtn.setOnClickListener(v->editNote(id)); actions.addView(noteBtn,new LinearLayout.LayoutParams(0,dp(46),1));
            Button logBtn=button("Bảo trì"); logBtn.setOnClickListener(v->addLog(id)); actions.addView(logBtn,new LinearLayout.LayoutParams(0,dp(46),1));
            Button mediaBtn=button("Ảnh/video"); mediaBtn.setOnClickListener(v->pickMedia(id)); actions.addView(mediaBtn,new LinearLayout.LayoutParams(0,dp(46),1)); shown++;
        }
        if(shown==0) { TextView empty=text("Không tìm thấy máy phù hợp.",15,Color.GRAY,false); empty.setPadding(dp(12),dp(24),dp(12),dp(24)); list.addView(empty); }
    }
    private String key(int id,String suffix){return "may_"+id+"_"+suffix;}
    private void editNote(int id) {
        EditText input=new EditText(this); input.setHint("Nhập thông tin máy, tình trạng, vị trí..."); input.setMinLines(3); input.setGravity(Gravity.TOP); input.setText(prefs.getString(key(id,"note"),""));
        new AlertDialog.Builder(this).setTitle("Thông tin Máy "+id).setView(input).setNegativeButton("Hủy",null).setPositiveButton("Lưu",(d,w)->{prefs.edit().putString(key(id,"note"),input.getText().toString().trim()).apply();renderMachines();Toast.makeText(this,"Đã lưu trên điện thoại",Toast.LENGTH_SHORT).show();}).show();
    }
    private void addLog(int id) {
        EditText input=new EditText(this); input.setHint("Nội dung sửa chữa, ngày bảo trì, vật tư..."); input.setMinLines(3); input.setGravity(Gravity.TOP);
        new AlertDialog.Builder(this).setTitle("Thêm hồ sơ bảo trì — Máy "+id).setView(input).setNegativeButton("Hủy",null).setPositiveButton("Lưu",(d,w)->{String line=new SimpleDateFormat("dd/MM/yyyy HH:mm",Locale.getDefault()).format(new Date())+" — "+input.getText().toString().trim(); String old=prefs.getString(key(id,"logs"),""); prefs.edit().putString(key(id,"logs"),old.isEmpty()?line:old+"\n"+line).apply();renderMachines();Toast.makeText(this,"Đã lưu hồ sơ bảo trì",Toast.LENGTH_SHORT).show();}).show();
    }
    private void pickMedia(int id) {
        pendingMachine=id; Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("*/*"); i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"image/*","video/*"}); i.addCategory(Intent.CATEGORY_OPENABLE); i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try { startActivityForResult(i,PICK_MEDIA); } catch(Exception e) { Toast.makeText(this,"Không mở được trình chọn tệp",Toast.LENGTH_LONG).show(); }
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data) {
        super.onActivityResult(requestCode,resultCode,data); if(requestCode==PICK_MEDIA && resultCode==RESULT_OK && data!=null && data.getData()!=null) {
            Uri uri=data.getData(); try { getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch(Exception ignored) {}
            String k=key(pendingMachine,"media"), old=prefs.getString(k,""); String value=old.isEmpty()?uri.toString():old+"\n"+uri.toString(); prefs.edit().putString(k,value).apply(); renderMachines(); Toast.makeText(this,"Đã gắn tệp ảnh/video vào Máy "+pendingMachine,Toast.LENGTH_LONG).show();
        }
    }
}
