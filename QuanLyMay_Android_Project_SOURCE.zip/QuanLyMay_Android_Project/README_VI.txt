QUẢN LÝ MÁY – DỰ ÁN ANDROID WEBVIEW

Đây là mã nguồn dự án Android Studio, CHƯA PHẢI file APK đã biên dịch.

Cách tạo APK:
1. Trên máy tính cài Android Studio phiên bản ổn định và Android SDK Platform 35.
2. Giải nén toàn bộ thư mục ZIP.
3. Android Studio > Open > chọn thư mục QuanLyMay_Android_Project.
4. Chờ Gradle Sync hoàn tất (cần Internet để tải Android Gradle Plugin/SDK nếu máy chưa có).
5. Chọn Build > Build APK(s).
6. APK thường nằm ở app/build/outputs/apk/debug/app-debug.apk.

Ứng dụng mở index.html nội bộ bằng WebView. Trợ lý AI trực tuyến vẫn cần triển khai worker.js lên Cloudflare Worker và cấu hình OPENAI_API_KEY dạng Secret; không nhúng API key vào ứng dụng.

LƯU Ý: Chưa thể xác nhận bản build hay mọi chức năng chạy hoàn hảo trên điện thoại thực tế trong môi trường tạo gói này. Hãy thử sao lưu dữ liệu trước khi dùng thật.
