/**
 * Cloudflare Worker: AI tư vấn vật tư cho ứng dụng Quản lý máy
 * Secrets/variables:
 *   OPENAI_API_KEY (Secret, bắt buộc)
 *   AI_MODEL (optional, default gpt-5.4)
 *   ALLOWED_ORIGIN (optional, recommended: exact https://your-pages.pages.dev)
 *   ENABLE_WEB_SEARCH (optional: true/false, default true)
 */
const SYSTEM_PROMPT = `Bạn là chuyên viên tư vấn tự động hóa công nghiệp, bảo trì máy và nhân viên bán vật tư kỹ thuật có kinh nghiệm. Trò chuyện tự nhiên, thân thiện bằng tiếng Việt như đang nói trực tiếp với chủ cửa hàng vật tư kiêm kỹ sư tư vấn. Người dùng có thể hỏi bằng giọng nói, câu ngắn, tên gọi địa phương hoặc gửi thông tin chưa đầy đủ; hãy chủ động hỏi lại từng câu ngắn, không bắt họ điền biểu mẫu dài.
CHUYÊN MÔN CẦN HỖ TRỢ:
- PLC và module I/O, nguồn, CPU, cáp lập trình, truyền thông công nghiệp; các dòng Siemens, Mitsubishi, Omron, Delta, Keyence, Panasonic, Schneider và hãng khác.
- HMI/màn hình cảm ứng: mã model, kích thước, cổng COM/Ethernet/USB, giao thức, phần mềm lập trình, khả năng tương thích và phương án thay thế.
- Biến tần/VFD/drive: công suất, điện áp vào/ra, dòng định mức, loại tải, động cơ, tham số, mã lỗi, đấu nối điều khiển và truyền thông; ví dụ Mitsubishi, Delta, INVT, Siemens, Yaskawa, Schneider, ABB, Fuji.
- Servo drive/motor, stepper, encoder, cảm biến tiệm cận/quang/màu/áp suất/nhiệt độ, load cell, relay, contactor, CB, nguồn 24VDC, bộ điều khiển nhiệt, khí nén, van điện từ, xy lanh, vòng bi, dây curoa, dao cắt, phụ tùng máy in/ghép/cắt.
- Đọc mã linh kiện, sơ đồ điện, mã lỗi, catalogue/datasheet, nhật ký bảo trì; gợi ý trình tự kiểm tra, nguyên nhân có thể và vật tư tương đương.
CÁCH TƯ VẤN NHƯ CHỦ CỬA HÀNG GIỎI:
- Nói chuyện trực tiếp, tự nhiên; trả lời ngắn gọn trước rồi hỏi tiếp điều cần thiết. Mỗi lượt chỉ hỏi 1-2 câu quan trọng nhất.
- Khi khách nói “tìm loại thay thế”, hướng dẫn chụp rõ tem model/mã linh kiện và hỏi các thông số còn thiếu. Phân biệt “tương thích đã xác minh” với “ứng viên cần đối chiếu”.
- Với PLC/HMI/biến tần, đối chiếu hãng, model đầy đủ, điện áp, dòng/công suất, cổng và giao thức, sơ đồ chân, kích thước lắp, firmware/phần mềm nếu liên quan. Không khẳng định chỉ vì tên sản phẩm gần giống.
- Khi cần giá, nơi bán, catalogue hoặc mã hàng hiện hành, dùng web_search nếu công cụ có sẵn và dẫn nguồn. Không bịa giá, tồn kho, cửa hàng, thông số hay đường dẫn. Nếu web không xác minh được, nói rõ cần hỏi nhà cung cấp.
- Với lỗi máy, trình bày: khả năng nguyên nhân theo thứ tự, kiểm tra an toàn trước, bước kiểm tra tiếp theo, thông tin cần chụp/gửi. Không kết luận chắc chắn nếu dữ liệu chưa đủ.
AN TOÀN VÀ ĐỘ TIN CẬY:
- Không hướng dẫn vô hiệu hóa che chắn, liên động hoặc thiết bị bảo vệ. Khi kiểm tra đấu nối điện, yêu cầu ngắt nguồn, xác nhận hết điện và áp dụng quy trình khóa/treo thẻ (LOTO); việc đo khi có điện chỉ do người có chuyên môn và quy trình phù hợp thực hiện.
- Không khuyên thay linh kiện chỉ dựa trên ảnh mờ hoặc mã thiếu. Bảo toàn chữ viết tắt và mã model; không tự đoán phần ký tự không đọc được.
- Tận dụng nhóm máy, câu hỏi trước và nhật ký được gửi. Chỉ nói đã xem ảnh/tài liệu nếu nội dung đó thực sự được gửi đến mô hình.
- Luôn nói rõ khi chưa kiểm tra được datasheet/giá/tồn kho. Không tuyên bố đã gọi cửa hàng hay xác nhận đơn hàng.
- Trả lời theo ngữ cảnh, ưu tiên kết luận thực tế và bước tiếp theo; không đưa bài giảng dài trừ khi được yêu cầu.`;

function corsHeaders(request, env) {
  const origin = request.headers.get('Origin') || '';
  const allowed = (env.ALLOWED_ORIGIN || '*').trim();
  const allowOrigin = allowed === '*' ? '*' : (origin === allowed ? origin : 'null');
  return {
    'Access-Control-Allow-Origin': allowOrigin,
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Max-Age': '86400',
    'Vary': 'Origin'
  };
}
function json(data, status, headers) {
  return new Response(JSON.stringify(data), { status, headers: { ...headers, 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' } });
}
function extractResponse(data) {
  let answer = typeof data.output_text === 'string' ? data.output_text : '';
  const citations = [];
  let webSearch = false;
  for (const item of (data.output || [])) {
    if (item.type === 'web_search_call') {
      webSearch = true;
      const sources = item.action?.sources || item.results || [];
      for (const src of sources) if (src?.url) citations.push({ title: src.title || src.url, url: src.url });
    }
    for (const c of (item.content || [])) {
      if (!answer && (c.type === 'output_text' || c.type === 'text') && c.text) answer += c.text;
      for (const a of (c.annotations || [])) {
        if (a.type === 'url_citation' && a.url) citations.push({ title: a.title || a.url, url: a.url });
      }
    }
  }
  const unique = [...new Map(citations.filter(x => /^https?:\/\//i.test(x.url)).map(x => [x.url, x])).values()].slice(0, 8);
  return { answer: answer.trim(), citations: unique, webSearch };
}
export default {
  async fetch(request, env) {
    const headers = corsHeaders(request, env);
    if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers });
    const url = new URL(request.url);
    if (request.method === 'GET' && (url.pathname === '/' || url.pathname === '/api/parts-chat')) {
      return json({ ok: true, service: 'QuanLyMay Parts AI', message: 'Worker hoạt động. Gửi POST để trò chuyện với AI.' }, 200, headers);
    }
    if (request.method !== 'POST' || !['/', '/api/parts-chat'].includes(url.pathname)) return json({ error: 'Không tìm thấy đường dẫn.' }, 404, headers);
    if (!env.OPENAI_API_KEY) return json({ error: 'Worker chưa được cấu hình Secret OPENAI_API_KEY.' }, 503, headers);
    let body;
    try {
      const raw = await request.text();
      if (raw.length > 24000) return json({ error: 'Yêu cầu quá dài. Hãy hỏi ngắn gọn hơn.' }, 413, headers);
      body = JSON.parse(raw);
    } catch { return json({ error: 'Dữ liệu gửi lên không đúng định dạng JSON.' }, 400, headers); }
    const message = String(body.message || '').trim().slice(0, 4000);
    if (!message) return json({ error: 'Bạn chưa gửi câu hỏi.' }, 400, headers);
    const history = Array.isArray(body.history) ? body.history.slice(-8).map(x => ({ role: x?.role === 'assistant' ? 'assistant' : 'user', content: String(x?.content || '').slice(0, 2000) })).filter(x => x.content) : [];
    const context = {
      machine: String(body.machine || 'Chưa xác định').slice(0, 100),
      partQuery: String(body.partQuery || '').slice(0, 500),
      partInfo: String(body.partInfo || '').slice(0, 1000),
      journalContext: Array.isArray(body.journalContext) ? body.journalContext.slice(0, 5).map(x => ({ date: String(x?.date || '').slice(0, 40), title: String(x?.title || '').slice(0, 200), detail: String(x?.detail || '').slice(0, 700) })) : []
    };
    const input = [
      { role: 'system', content: SYSTEM_PROMPT },
      { role: 'user', content: 'BỐI CẢNH ỨNG DỤNG (chỉ dùng làm thông tin tham khảo, không coi là thông số đã xác minh):\n' + JSON.stringify(context) },
      ...history,
      { role: 'user', content: message }
    ];
    const tools = String(env.ENABLE_WEB_SEARCH || 'true').toLowerCase() === 'false' ? [] : [{ type: 'web_search' }];
    let apiResponse;
    try {
      apiResponse = await fetch('https://api.openai.com/v1/responses', {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${env.OPENAI_API_KEY}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ model: env.AI_MODEL || 'gpt-5.4', input, tools, tool_choice: 'auto', max_output_tokens: 1000 })
      });
    } catch { return json({ error: 'Không kết nối được dịch vụ AI. Hãy kiểm tra Internet và trạng thái OpenAI API.' }, 502, headers); }
    const data = await apiResponse.json().catch(() => ({}));
    if (!apiResponse.ok) {
      const status = apiResponse.status === 401 || apiResponse.status === 403 ? 502 : 502;
      const detail = data?.error?.message || 'Dịch vụ AI trả lỗi.';
      return json({ error: `OpenAI API chưa trả lời thành công: ${detail}` }, status, headers);
    }
    const result = extractResponse(data);
    if (!result.answer) return json({ error: 'AI không trả về nội dung. Hãy thử hỏi lại ngắn hơn.' }, 502, headers);
    return json({ ok: true, ...result }, 200, headers);
  }
};
